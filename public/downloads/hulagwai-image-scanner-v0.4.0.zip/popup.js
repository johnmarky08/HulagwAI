const backendInput = document.querySelector("#backend-url");
const siteForm = document.querySelector("#site-form");
const pairForm = document.querySelector("#pair-form");
const pairInput = document.querySelector("#pair-code");
const status = document.querySelector("#connection-status");
const tokenStatus = document.querySelector("#token-status");
const disconnectButton = document.querySelector("#disconnect");
const enabledInput = document.querySelector("#enabled");
const logList = document.querySelector("#log-list");
const clearButton = document.querySelector("#clear-log");
const LOG_KEY = "scanLog";

function showStatus(message, kind = "") {
  status.textContent = message;
  status.className = `status ${kind}`.trim();
}

function normalizeBaseUrl(value) {
  const parsed = new URL(value);
  if (!["http:", "https:"].includes(parsed.protocol) || parsed.username || parsed.password) {
    throw new Error("Use a valid HTTP or HTTPS site address.");
  }
  if (parsed.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(parsed.hostname)) {
    throw new Error("Use HTTPS for a non-local HulagwAI site.");
  }
  return parsed.origin;
}

function renderLogs(logs = []) {
  logList.replaceChildren();
  if (!logs.length) {
    const empty = document.createElement("li");
    empty.className = "empty";
    empty.textContent = "No scan attempts yet.";
    logList.append(empty);
    return;
  }
  for (const entry of logs) {
    const row = document.createElement("li");
    const time = document.createElement("time");
    time.textContent = entry.time || "";
    const message = document.createElement("span");
    const stage = document.createElement("b");
    stage.textContent = (entry.stage || "event").replaceAll("_", " ");
    message.append(stage, document.createTextNode(` · ${entry.message || ""}`));
    if (entry.analysisId) message.append(document.createElement("br"), document.createTextNode(`Analysis ${entry.analysisId}`));
    row.append(time, message);
    logList.append(row);
  }
}

async function readJson(response) {
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message || `Request failed (HTTP ${response.status}).`);
  return payload;
}

async function refreshTokenStatus() {
  const stored = await chrome.storage.local.get(["backendUrl", "extensionToken", "tokenExpiresAt", "enabled"]);
  enabledInput.checked = Boolean(stored.enabled);
  enabledInput.disabled = !stored.extensionToken;
  disconnectButton.hidden = !stored.extensionToken;
  if (stored.extensionToken) {
    const expiry = stored.tokenExpiresAt ? new Date(stored.tokenExpiresAt).toLocaleDateString() : "unknown";
    tokenStatus.textContent = `Paired · expires ${expiry}`;
    if (stored.backendUrl) showStatus(`Paired with ${stored.backendUrl}.`, "success");
  } else {
    tokenStatus.textContent = "Not paired";
  }
}

async function initialize() {
  const stored = await chrome.storage.local.get(["backendUrl", "extensionToken", "tokenExpiresAt", "enabled", LOG_KEY]);
  if (stored.backendUrl) backendInput.value = stored.backendUrl;
  renderLogs(stored[LOG_KEY] || []);
  await refreshTokenStatus();
}

siteForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  let base;
  try {
    base = normalizeBaseUrl(backendInput.value.trim());
  } catch (error) {
    showStatus(error.message, "error");
    return;
  }

  const origin = `${base}/*`;
  const permissionRequest = chrome.permissions.request({ origins: [origin] });
  showStatus("Requesting access to this HulagwAI site…");
  try {
    const granted = await permissionRequest;
    if (!granted) throw new Error("Site permission was not granted.");
    await chrome.storage.local.set({ backendUrl: base });
    await chrome.tabs.create({ url: `${base}/extension/connect` });
    showStatus("Pairing page opened. Sign in if asked, then copy its one-time code here.", "success");
  } catch (error) {
    showStatus(error.message || "Could not open the HulagwAI pairing page.", "error");
  }
});

pairForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  let base;
  try {
    base = normalizeBaseUrl(backendInput.value.trim());
  } catch (error) {
    showStatus(error.message, "error");
    return;
  }
  const code = pairInput.value.trim().toLowerCase();
  if (!/^[a-f0-9]{32}$/.test(code)) {
    showStatus("Paste the 32-character code from the HulagwAI pairing page.", "error");
    return;
  }
  const hasPermission = await chrome.permissions.contains({ origins: [`${base}/*`] });
  if (!hasPermission) {
    showStatus("Open the secure pairing page first to grant access to this HulagwAI site.", "error");
    return;
  }

  showStatus("Exchanging the one-time code for a private extension token…");
  try {
    const response = await fetch(`${base}/api/v1/extension/exchange`, {
      method: "POST",
      credentials: "omit",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    });
    const payload = await readJson(response);
    if (typeof payload.token !== "string" || !/^[a-f0-9]{64}$/i.test(payload.token)) {
      throw new Error("HulagwAI returned an invalid extension token.");
    }
    await chrome.storage.local.set({
      backendUrl: base,
      extensionToken: payload.token,
      tokenExpiresAt: payload.expires_at,
      enabled: true,
    });
    pairInput.value = "";
    await refreshTokenStatus();
    showStatus("Extension paired. Right-click an image on any website and choose Scan image with HulagwAI.", "success");
  } catch (error) {
    showStatus(error.message || "Pairing failed. Generate a fresh one-time code.", "error");
  }
});

enabledInput.addEventListener("change", async () => {
  await chrome.storage.local.set({ enabled: enabledInput.checked });
});

disconnectButton.addEventListener("click", async () => {
  const stored = await chrome.storage.local.get(["backendUrl", "extensionToken"]);
  try {
    if (stored.backendUrl && stored.extensionToken) {
      const response = await fetch(`${stored.backendUrl}/api/v1/extension/token`, {
        method: "DELETE",
        credentials: "omit",
        headers: { Accept: "application/json", Authorization: `Bearer ${stored.extensionToken}` },
      });
      if (!response.ok && response.status !== 401) {
        throw new Error(`The server could not revoke this token (HTTP ${response.status}).`);
      }
    }
    await chrome.storage.local.remove(["extensionToken", "tokenExpiresAt"]);
    await chrome.storage.local.set({ enabled: false });
    await refreshTokenStatus();
    showStatus("This extension token has been disconnected.");
  } catch (error) {
    showStatus(error.message || "Could not revoke the extension token. Check your connection and try again.", "error");
  }
});

clearButton.addEventListener("click", async () => {
  await chrome.storage.local.set({ [LOG_KEY]: [] });
  renderLogs([]);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[LOG_KEY]) renderLogs(changes[LOG_KEY].newValue || []);
  if (changes.enabled) enabledInput.checked = Boolean(changes.enabled.newValue);
  if (changes.extensionToken || changes.tokenExpiresAt) void refreshTokenStatus();
});

initialize().catch((error) => showStatus(error.message || "Could not load extension settings.", "error"));
