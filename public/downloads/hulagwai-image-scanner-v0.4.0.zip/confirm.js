const params = new URLSearchParams(location.search);
const requestId = params.get("id") || "";
const pendingKey = `pendingScan:${requestId}`;
const host = document.querySelector("#image-host");
const pairState = document.querySelector("#pair-state");
const status = document.querySelector("#status");
const permissionBox = document.querySelector("#permission-box");
const permissionCopy = document.querySelector("#permission-copy");
const preview = document.querySelector("#selected-preview");
const previewPlaceholder = document.querySelector("#preview-placeholder");
const grantButton = document.querySelector("#grant-access");
const confirmButton = document.querySelector("#confirm");
const cancelButton = document.querySelector("#cancel");
let pending = null;
let imageOriginPattern = "";
let accessGranted = false;
let paired = false;
let busy = false;

function showStatus(message, kind = "") {
  status.textContent = message;
  status.className = `status ${kind}`.trim();
}

preview.addEventListener("load", () => {
  preview.hidden = false;
  previewPlaceholder.hidden = true;
});
preview.addEventListener("error", () => {
  preview.hidden = true;
  previewPlaceholder.hidden = false;
  previewPlaceholder.textContent = "The source blocked its preview. You may still confirm the fetch for analysis.";
});

function isTrustedPendingUrl(raw) {
  try {
    const url = new URL(raw);
    return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password;
  } catch {
    return false;
  }
}

async function refreshState() {
  if (!pending) return;
  const [hasImageAccess, stored] = await Promise.all([
    chrome.permissions.contains({ origins: [imageOriginPattern] }),
    chrome.storage.local.get(["backendUrl", "extensionToken"]),
  ]);
  accessGranted = hasImageAccess;
  paired = Boolean(stored.backendUrl && stored.extensionToken);
  permissionBox.hidden = accessGranted;
  confirmButton.disabled = !accessGranted || !paired || busy;
  pairState.textContent = paired ? "Paired with your account" : "Not paired yet";
  if (accessGranted) {
    if (preview.getAttribute("src") !== pending.imageUrl) {
      previewPlaceholder.hidden = false;
      previewPlaceholder.textContent = "Loading selected image preview…";
      preview.src = pending.imageUrl;
    }
  } else {
    preview.removeAttribute("src");
    preview.hidden = true;
    previewPlaceholder.hidden = false;
    previewPlaceholder.textContent = "Grant image-host access to preview the selected image here.";
  }
  if (!accessGranted) {
    showStatus("Grant access for this image host, then confirm the scan. You can revoke it in browser settings.");
  } else if (!paired) {
    showStatus("Pair HulagwAI from the extension toolbar first, then return here.", "error");
  } else {
    showStatus("Ready. The image will only be uploaded if you choose Send image for analysis.", "success");
  }
}

async function initialize() {
  if (!/^[a-f0-9-]{20,64}$/i.test(requestId)) {
    showStatus("This scan request is invalid. Right-click an image and try again.", "error");
    confirmButton.disabled = true;
    grantButton.disabled = true;
    return;
  }
  const result = await chrome.storage.session.get(pendingKey);
  pending = result[pendingKey];
  if (!pending || Date.now() - pending.createdAt > 10 * 60 * 1000) {
    await chrome.storage.session.remove(pendingKey);
    host.textContent = "Unavailable";
    showStatus("The selected image request expired. Right-click the image again.", "error");
    confirmButton.disabled = true;
    grantButton.disabled = true;
    return;
  }
  if (pending.error || !isTrustedPendingUrl(pending.imageUrl)) {
    host.textContent = "Unsupported image address";
    showStatus(pending.error || "Only HTTP or HTTPS image URLs can be scanned.", "error");
    confirmButton.disabled = true;
    grantButton.disabled = true;
    return;
  }

  const imageUrl = new URL(pending.imageUrl);
  imageOriginPattern = `${imageUrl.origin}/*`;
  host.textContent = imageUrl.hostname;
  permissionCopy.textContent = `Allow HulagwAI Image Scanner to fetch the selected image from ${imageUrl.hostname}. This grants access only to this image host; your page URL and browsing history are not sent.`;
  await refreshState();
}

grantButton.addEventListener("click", async () => {
  if (!imageOriginPattern || busy) return;
  grantButton.disabled = true;
  showStatus("Requesting access to this image host…");
  try {
    const granted = await chrome.permissions.request({ origins: [imageOriginPattern] });
    if (!granted) {
      showStatus("Permission was not granted. Nothing was uploaded.", "error");
      grantButton.disabled = false;
      return;
    }
    await refreshState();
  } catch (error) {
    showStatus(error.message || "Could not request image-host access.", "error");
    grantButton.disabled = false;
  }
});

confirmButton.addEventListener("click", () => {
  if (!pending || !accessGranted || !paired || busy) return;
  busy = true;
  confirmButton.disabled = true;
  cancelButton.disabled = true;
  grantButton.disabled = true;
  confirmButton.textContent = "Analyzing…";
  showStatus("Fetching the selected image, then sending it to HulagwAI…");
  chrome.runtime.sendMessage({ type: "HULAGWAI_CONFIRM_SCAN", requestId }, async (response) => {
    if (chrome.runtime.lastError) {
      busy = false;
      cancelButton.disabled = false;
      confirmButton.disabled = false;
      confirmButton.textContent = "Retry scan";
      showStatus(chrome.runtime.lastError.message, "error");
      return;
    }
    if (!response?.ok) {
      busy = false;
      cancelButton.disabled = false;
      confirmButton.disabled = false;
      confirmButton.textContent = "Retry scan";
      showStatus(response?.error || "The scan could not be completed.", "error");
      return;
    }
    const result = response.result;
    showStatus(`${result.label} · ${result.confidencePercent}% confidence · Analysis ${result.analysisId}`, "success");
    confirmButton.textContent = "Analysis complete";
    cancelButton.disabled = false;
    cancelButton.textContent = "Close";
  });
});

cancelButton.addEventListener("click", () => {
  if (!busy || cancelButton.textContent === "Close") {
    chrome.runtime.sendMessage({ type: "HULAGWAI_CANCEL_PENDING_SCAN", requestId });
    window.close();
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.backendUrl || changes.extensionToken)) void refreshState();
});

initialize().catch((error) => {
  showStatus(error.message || "Could not load the selected image request.", "error");
  confirmButton.disabled = true;
  grantButton.disabled = true;
});
